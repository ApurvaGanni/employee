// Mock employee data
let employees = [
    {
        id: 1,
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@example.com",
        department: "Engineering",
        role: "Developer"
    },
    {
        id: 2,
        firstName: "Jane",
        lastName: "Smith",
        email: "jane.smith@example.com",
        department: "Sales",
        role: "Manager"
    },
    {
        id: 3,
        firstName: "Mike",
        lastName: "Johnson",
        email: "mike.j@example.com",
        department: "HR",
        role: "Analyst"
    }
];

// Current page and page size
let currentPage = 1;
let pageSize = 10;
let filteredEmployees = [...employees];

// DOM Elements
const searchInput = document.getElementById('search');
const filterDepartment = document.getElementById('filter-department');
const filterRole = document.getElementById('filter-role');
const sortSelect = document.getElementById('sort');
const pageSizeSelect = document.getElementById('pageSize');
const prevPageBtn = document.getElementById('prevPage');
const nextPageBtn = document.getElementById('nextPage');
const pageInfo = document.getElementById('pageInfo');
const filterSidebar = document.getElementById('filter-sidebar');

// Initialize
function initialize() {
    // Set up event listeners
    searchInput.addEventListener('input', handleSearch);
    filterDepartment.addEventListener('change', handleFilter);
    filterRole.addEventListener('change', handleFilter);
    sortSelect.addEventListener('change', handleSort);
    pageSizeSelect.addEventListener('change', handlePageSizeChange);
    prevPageBtn.addEventListener('click', handlePrevPage);
    nextPageBtn.addEventListener('click', handleNextPage);
    
    // Initial render
    updatePagination();
    renderEmployees();
}

// Toggle filter sidebar
function toggleFilter() {
    filterSidebar.classList.toggle('active');
}

// Handle search
function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    filteredEmployees = employees.filter(emp => 
        emp.firstName.toLowerCase().includes(searchTerm) || 
        emp.lastName.toLowerCase().includes(searchTerm) ||
        emp.email.toLowerCase().includes(searchTerm)
    );
    currentPage = 1;
    updatePagination();
    renderEmployees();
}

// Handle filter
function handleFilter() {
    const department = filterDepartment.value;
    const role = filterRole.value;
    
    filteredEmployees = employees.filter(emp => {
        const matchesDepartment = !department || emp.department === department;
        const matchesRole = !role || emp.role === role;
        return matchesDepartment && matchesRole;
    });
    
    currentPage = 1;
    updatePagination();
    renderEmployees();
}

// Handle sort
function handleSort() {
    const sortField = sortSelect.value;
    if (sortField) {
        filteredEmployees.sort((a, b) => {
            return a[sortField].localeCompare(b[sortField]);
        });
    }
    renderEmployees();
}

// Handle page size change
function handlePageSizeChange() {
    pageSize = parseInt(pageSizeSelect.value);
    currentPage = 1;
    updatePagination();
    renderEmployees();
}

// Handle pagination
function handlePrevPage() {
    if (currentPage > 1) {
        currentPage--;
        renderEmployees();
    }
}

function handleNextPage() {
    const totalPages = Math.ceil(filteredEmployees.length / pageSize);
    if (currentPage < totalPages) {
        currentPage++;
        renderEmployees();
    }
}

// Update pagination info
function updatePagination() {
    const totalPages = Math.ceil(filteredEmployees.length / pageSize);
    pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    
    prevPageBtn.disabled = currentPage === 1;
    nextPageBtn.disabled = currentPage === totalPages;
}

// Render employees
function renderEmployees() {
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;
    const currentEmployees = filteredEmployees.slice(start, end);
    
    const employeeGrid = document.querySelector('.employee-grid');
    employeeGrid.innerHTML = '';
    
    currentEmployees.forEach(emp => {
        const card = document.createElement('div');
        card.className = 'employee-card';
        
        card.innerHTML = `
            <div class="employee-info">
                <h3>${emp.firstName} ${emp.lastName}</h3>
                <p class="employee-id">ID: ${emp.id}</p>
                <p class="employee-email">${emp.email}</p>
                <div class="employee-meta">
                    <span class="badge">${emp.department}</span>
                    <span class="badge">${emp.role}</span>
                </div>
            </div>
            <div class="card-actions">
                <a href="form.ftl?id=${emp.id}" class="btn btn-edit">Edit</a>
                <button class="btn btn-delete" onclick="deleteEmployee(${emp.id})">Delete</button>
            </div>
        `;
        
        employeeGrid.appendChild(card);
    });
}

// Delete employee
function deleteEmployee(id) {
    if (confirm('Are you sure you want to delete this employee?')) {
        const index = employees.findIndex(emp => emp.id === id);
        if (index !== -1) {
            employees.splice(index, 1);
            filteredEmployees = [...employees]; // Refresh filtered list
            currentPage = 1;
            updatePagination();
            renderEmployees();
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', initialize);