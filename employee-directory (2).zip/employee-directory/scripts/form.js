// Get URL parameters
const urlParams = new URLSearchParams(window.location.search);
const empId = urlParams.get('id');

// DOM Elements
const form = document.getElementById('employeeForm');
const firstNameInput = document.getElementById('firstName');
const lastNameInput = document.getElementById('lastName');
const emailInput = document.getElementById('email');
const departmentInput = document.getElementById('department');
const roleInput = document.getElementById('role');

// Error message elements
const errorMessages = {
    firstName: document.getElementById('firstNameError'),
    lastName: document.getElementById('lastNameError'),
    email: document.getElementById('emailError'),
    department: document.getElementById('departmentError'),
    role: document.getElementById('roleError')
};

// Initialize form
function initializeForm() {
    // Set form title based on mode
    const title = document.querySelector('h1');
    title.textContent = empId ? 'Edit Employee' : 'Add New Employee';
    
    // If editing, populate form with existing data
    if (empId) {
        fetchEmployeeData(empId);
    }
}

// Fetch employee data if editing
async function fetchEmployeeData(id) {
    try {
        const response = await fetch('index.ftl');
        const text = await response.text();
        
        const scriptTag = text.match(/<#assign employees = \[(.*?)\]/s);
        if (scriptTag) {
            const employeesData = scriptTag[1];
            const employees = eval(`[${employeesData}]`);
            
            const employee = employees.find(e => e.id === parseInt(id));
            if (employee) {
                populateForm(employee);
            }
        }
    } catch (error) {
        console.error('Error fetching employee data:', error);
        showError('Failed to load employee data');
    }
}

// Populate form with employee data
function populateForm(employee) {
    firstNameInput.value = employee.firstName;
    lastNameInput.value = employee.lastName;
    emailInput.value = employee.email;
    departmentInput.value = employee.department;
    roleInput.value = employee.role;
}

// Form validation
function validateForm() {
    let isValid = true;
    const errors = {};
    
    // Clear all error messages
    Object.values(errorMessages).forEach(el => {
        el.textContent = '';
    });

    // Validate each field
    if (!firstNameInput.value.trim()) {
        errors.firstName = 'First name is required';
        isValid = false;
    }
    
    if (!lastNameInput.value.trim()) {
        errors.lastName = 'Last name is required';
        isValid = false;
    }
    
    if (!emailInput.value.trim()) {
        errors.email = 'Email is required';
        isValid = false;
    } else if (!validateEmail(emailInput.value)) {
        errors.email = 'Please enter a valid email address';
        isValid = false;
    }
    
    if (!departmentInput.value.trim()) {
        errors.department = 'Department is required';
        isValid = false;
    }
    
    if (!roleInput.value.trim()) {
        errors.role = 'Role is required';
        isValid = false;
    }
    
    // Display errors
    Object.entries(errors).forEach(([field, message]) => {
        if (message) {
            errorMessages[field].textContent = message;
        }
    });
    
    return isValid;
}

// Email validation
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Handle form submission
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
        return;
    }
    
    const employeeData = {
        firstName: firstNameInput.value,
        lastName: lastNameInput.value,
        email: emailInput.value,
        department: departmentInput.value,
        role: roleInput.value
    };
    
    try {
        if (empId) {
            await updateEmployee(empId, employeeData);
        } else {
            await addEmployee(employeeData);
        }
        
        // Redirect back to dashboard
        window.location.href = 'index.ftl';
    } catch (error) {
        console.error('Error saving employee:', error);
        showError('Failed to save employee');
    }
});

// Show error message
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    form.insertBefore(errorDiv, form.firstChild);
    
    // Remove error after 5 seconds
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

// Add employee (in a real app, this would call a backend API)
async function addEmployee(data) {
    const response = await fetch('index.ftl');
    const text = await response.text();
    
    const scriptTag = text.match(/<#assign employees = \[(.*?)\]/s);
    if (scriptTag) {
        const employeesData = scriptTag[1];
        const employees = eval(`[${employeesData}]`);
        const nextId = employees.length > 0 ? Math.max(...employees.map(e => e.id)) + 1 : 1;
        
        employees.push({
            id: nextId,
            ...data
        });
        
        const newScript = `<#assign employees = ${JSON.stringify(employees)}>`;
        const newText = text.replace(scriptTag[0], newScript);
        
        console.log('New employee added:', data);
    }
}

// Update employee (in a real app, this would call a backend API)
async function updateEmployee(id, data) {
    const response = await fetch('index.ftl');
    const text = await response.text();
    
    const scriptTag = text.match(/<#assign employees = \[(.*?)\]/s);
    if (scriptTag) {
        const employeesData = scriptTag[1];
        const employees = eval(`[${employeesData}]`);
        
        const index = employees.findIndex(e => e.id === parseInt(id));
        if (index !== -1) {
            employees[index] = {
                ...employees[index],
                ...data
            };
            
            const newScript = `<#assign employees = ${JSON.stringify(employees)}>`;
            const newText = text.replace(scriptTag[0], newScript);
            
            console.log('Employee updated:', data);
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeForm);